﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class NewStudent : Form
    {
        public NewStudent()
        {
            InitializeComponent();
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            bool isVal = true;
            try
            {
                errorPName.Clear();
                errorPID.Clear();
                var Sname = Student.findName(txtName.Text);
                var Sid = Student.findId(int.Parse(txtID.Text));
                if(Sname != null)
                {
                    isVal = false;
                    errorPName.SetError(txtName, "Name already exists");
                }
                else if(txtName.TextLength < 3)
                {
                    isVal=false;
                    errorPName.SetError(txtName, "Name should have more than 3 characters");
                }

                if(Sid != null)
                {
                    isVal = false;
                    errorPID.SetError(txtID, "ID already exists");
                }
            }
            catch
            {
                errorPName.SetError(txtName, "Name is required");
                errorPID.SetError(txtID, "Id is required");
            }


            if(string.IsNullOrEmpty(txtBatch.Text))
            {
                isVal = false;
                errorPBatch.SetError(txtBatch, "Batch is required");
            }
            else if (txtBatch.TextLength !=4)
            {
                isVal = false;
                errorPBatch.SetError(txtBatch, "Enter correct batch");
            }
            else
                errorPBatch.Clear();

            if(isVal)
            {
                Student s1 = new Student
                {
                    Name = txtName.Text,
                    id = int.Parse(txtID.Text),
                    dob = txt_Date.Text,
                    Batch = txtBatch.Text,
                };
                MessageBox.Show("Added!\n");
                s1.save();
                txtID.Text = (s1.id + 1).ToString();
            }
        }
    }
}
