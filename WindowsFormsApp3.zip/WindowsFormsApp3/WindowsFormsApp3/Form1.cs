﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp3;


namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        public string Username { get; set; }
        public Form1(string user)
        {
            InitializeComponent();
            Username = user;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Boolean isVal = true;

            Regex regex = new Regex(@"^[a-z]{2}$");
            if (regex.IsMatch(txt_ObjectName.Text))
            {
                isVal = false;
                errorProviderName.SetError(txt_ObjectName, "2 digit name");
            }
            if (string.IsNullOrEmpty(txt_ObjectName.Text))
            {
                isVal = false;
                errorProviderName.SetError(txt_ObjectName, "Name is Required");
            }
            else if (txt_ObjectName.TextLength < 3)
            {
                isVal = false;
                errorProviderName.SetError(txt_ObjectName, "Name should have more than 3 char");
            }
            else
                errorProviderName.Clear();
            if (string.IsNullOrEmpty(txt_InventoryNumber.Text))
            {
                isVal = false;
                errorProviderInventory.SetError(txt_InventoryNumber, "Inventiry Number is Required");              
            }
            else
                errorProviderInventory.Clear();
            if (string.IsNullOrEmpty(txt_Num.Text))
            {
                isVal = false;
                errorProviderNum.SetError(txt_Num, "Number is Required");
            }
            else
                errorProviderNum.Clear();

            if (string.IsNullOrEmpty(txt_Count.Text) || int.Parse(txt_Count.Text) <= 0)
            {
                isVal = false;
                errorProviderCount.SetError(txt_Count, "Count is Required");
            }
            else
                errorProviderCount.Clear();
            try
            {
                errorProviderPrice.Clear();
                double.Parse(txt_Price.Text);
            }
            catch (Exception)
            {
                errorProviderPrice.SetError(txt_Price, "Price is required");
            }
            if (isVal)
            {
                Product m1 = new Product
                {
                    number = int.Parse(txt_Num.Text),
                    date = datetxt.Text,
                    invnumb = int.Parse(txt_InventoryNumber.Text),
                    objname = txt_ObjectName.Text,
                    count = int.Parse(txt_Count.Text),
                    price = double.Parse(txt_Price.Text),
                    available = chk_IsAvailable.Checked,
                };
            MessageBox.Show("SAVED");
                MessageBox.Show("Simple");
                if (radioButton1.Checked)
                {
                    MessageBox.Show("Simple");
                }
                else if (radioButton2.Checked)
                {
                    MessageBox.Show("Variable");
                }
            m1.save();
            ProductView1.DataSource = null;
            ProductView1.DataSource = Product.GetAll();
            }


        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        
        

        private void datetxt_ValueChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void chk_IsAvailable_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
