﻿namespace WindowsFormsApp3
{
    partial class DisplayProducts
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DisplayProduct = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.DisplayProduct)).BeginInit();
            this.SuspendLayout();
            // 
            // DisplayProducts
            // 
            this.DisplayProduct.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DisplayProduct.Location = new System.Drawing.Point(76, 89);
            this.DisplayProduct.Name = "DisplayProducts";
            this.DisplayProduct.Size = new System.Drawing.Size(615, 309);
            this.DisplayProduct.TabIndex = 0;
            // 
            // DisplayProduct
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.DisplayProduct);
            this.Name = "DisplayProduct";
            this.Text = "DisplayProduct";
            ((System.ComponentModel.ISupportInitialize)(this.DisplayProduct)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView DisplayProduct;
    }
}